<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['ContactDesc'] = 'Apakah Anda memiliki pertanyaan tentang perusahaan kami, produk atau layanan kami?';
$lang['fieldName'] = 'Nama Anda';

$lang['fieldEmail'] = 'Email Anda';

$lang['fieldMessage'] = 'Pesan';

$lang['fieldBtnSubmit'] = 'Kirim';

$lang['contact_phone'] = 'Telepon';

$lang['contact_success'] = 'Selamat, pesan Anda berhasil disampaikan! ';