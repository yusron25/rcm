<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$lang['home'] = 'Beranda';
$lang['profile'] = 'Profil';
$lang['gallery'] = 'Galeri';
$lang['service'] = 'Layanan';
$lang['contact'] = 'Hubungi Kami';
$lang['language'] = 'Bahasa';
$lang['english'] = 'Inggris';
$lang['indonesian'] = 'Indonesia';