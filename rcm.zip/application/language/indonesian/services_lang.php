<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['business_repair'] = 'Kami memiliki teknisi yang andal dan kompeten <span class="collapse" id="mrcollapse">untuk melakukan pemeliharaan dan perbaikan alat berat sesuai dengan Standar operation prosedur dari mulai preventive maintenance, corrective maintenance, penanganan troubleshooting sampai dengan over houl.</span> <a class="collapers" href="#" data-toggle="collapse" data-target="#mrcollapse" aria-expanded="false" aria-controls="mrcollapse">Read More..</a>';

$lang['business_sparepart'] = 'Menyediakan suku cadang alat-alat berat <span class="collapse" id="spcollapse">dengan kualitas terjamin dan harga yang kompetitif dari mulai consumable part, engine, cylinder, turbo, generator dan spare partlainnya.</span><a class="collapers" href="#" data-toggle="collapse" data-target="#spcollapse" aria-expanded="false" aria-controls="spcollapse">Read More..</a>';

$lang['business_transportation'] = 'Menyediakan sarana transportasi berupa trucking kontainer <span class="collapse" id="itcollapse">ukuran 40 feet dengan armada baru untuk kebutuhan pengiriman ke seluruh wilayah.</span><a class="collapers" href="#" data-toggle="collapse" data-target="#itcollapse" aria-expanded="false" aria-controls="itcollapse">Read More..</a>';

$lang['business_rental'] = 'Penyewaan alat-alat bongkar muat kontainer <span class="collapse" id="recollapse">seperti harbor mobile crane (HMC), reachstacker (RS), sideloader (SL) untuk menunjang kegiatan stevedoring, receiving delivery container baik di Pelabuha nmaupun Depo container dengan menempatkan alat-alat yang handal serta dioperasikan oleh operator yang berpengalaman dan bersertifikat.</span><a class="collapers" href="#" data-toggle="collapse" data-target="#recollapse" aria-expanded="false" aria-controls="recollapse">Read More..</a>';


$lang['business_title'] = 'Bisnis';