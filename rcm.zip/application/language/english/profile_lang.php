<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$lang['profile_title'] = 'Profile';

$lang['profile_company'] = 'Company Name';
$lang['profile_address'] = 'Address';
$lang['profile_bussiness'] = 'Main Bussiness';
$lang['profile_director'] = 'President Director';
$lang['profile_employee'] = 'Number Employee';

$lang['profile_visinmisi'] = 'Vision & Mission';

$lang['profile_visititle'] = 'Vision';
$lang['profile_misititle'] = 'Mission';
$lang['profile_visidesc'] = '"Being the world class company bases solution and oriented to customer satisfactions."';
$lang['profile_misidesc'] = '<ul style="list-style: disc;">
	<li>Providing quality products and services.</li>
	<li>Provide solutions and best result.</li>
	<li>Generate sustainable added value to all parties.</li>
	<li>Helping customer to achieve  business success.</li>
</ul>';

$lang['profile_value'] = 'Value';

$lang['about_us_title'] = 'About Us';
$lang['about_us_desc'] = 'PT Rajawali Cahaya Mandiri is a distributor and rental company in the field of heavy equipment, including also provide spare part and maintenance services and repair heavy equipment.
PT Rajawali Cahaya Mandiri started up in 2013, started from special heavy equipment rental business container handler including operator services and competent technicians that operate in the area of port Tanjung Priok in Jakarta. As time goes by, our services are more trusted by customers and through them, so we expanded up at several places in Jakarta and surrounding area. Simultaneously we are developing business in the sale of heavy equipment and spare part, including container handler (SL), reach stacker (RS) and crane.';

$lang['value_teamwork_title'] = 'Teamwork';
$lang['value_integrity_title'] = 'Integrity';
$lang['value_customer_title'] = 'Customer Priority';
$lang['value_care_title'] = 'Care';
$lang['value_innovation_title'] = 'Innovation';
$lang['value_responsibility_title'] ='Responsibility';

$lang['value_teamwork_desc'] = 'Prioritizing teamwork in executing and completing the work to achieve a mutually agreed outcome effectively and efficiently. ';
$lang['value_integrity_desc'] = 'Trustworthy, honest, and impartial.';
$lang['value_customer_desc'] = 'To give satisfaction to customer with implementation and complete work.';
$lang['value_care_desc'] = 'Giving priority to the common interest of others and the environment.';
$lang['value_innovation_desc'] = 'Continuous improvement by providing added value to all parties so as to provide benefits for the common good.';
$lang['value_responsibility_desc'] = 'Aware in completing the work as a liability.';