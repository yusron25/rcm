<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['ContactDesc'] = 'Do you have questions about our company, products or any of our services?';
$lang['fieldName'] = 'Your Name';

$lang['fieldEmail'] = 'Your Email';

$lang['fieldMessage'] = 'Messages';

$lang['fieldBtnSubmit'] = 'Submit Now';

$lang['contact_phone'] = 'Phone';

$lang['contact_success'] = 'Well Done, Your Messages was successfully delivered! ';