<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$lang['home'] = 'Home';
$lang['profile'] = 'Profile';
$lang['gallery'] = 'Gallery';
$lang['service'] = 'Services';
$lang['contact'] = 'Contact Us';
$lang['language'] = 'Languages';
$lang['english'] = 'English';
$lang['indonesian'] = 'Indonesian';